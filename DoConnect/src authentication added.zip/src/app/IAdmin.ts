export interface IAdmin{
    id : number;
    adminName : string;
    password : string;
    adminEmail : string;
}