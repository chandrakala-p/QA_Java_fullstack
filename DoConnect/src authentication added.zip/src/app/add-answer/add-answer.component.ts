import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Answer } from '../answer';
import { AnswerService } from '../services/answer.service';

@Component({
  selector: 'app-add-answer',
  templateUrl: './add-answer.component.html',
  styleUrls: ['./add-answer.component.css']
})
export class AddAnswerComponent implements OnInit {

  answer: Answer = new Answer();
  user:any;
  submitted = false;

  constructor(private answerService: AnswerService, private router: Router) { }

  ngOnInit() {
    this.user=localStorage.getItem("authUser");
    this.user=JSON.parse(this.user);

  }

  newUser(): void {
    this.submitted = false;
    this.answer = new Answer();
  }

  save() {
    this.answerService.addAnswerByUserId(this.user.id,this.answer)
      .subscribe(data => console.log(data), error => console.log(error));
    this.answer = new Answer();
    this.answersList();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }


  answersList() {
    this.router.navigate(['answers']);
  }

}
