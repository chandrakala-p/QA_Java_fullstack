import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Question } from '../question';
import { QuestionService } from '../services/question.service';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {

  questions!: Question[];
  id!: number;
  question1: Question = new Question();
  question: any;

  isLoading = true;
  color = 'primary';
  mode = 'determinate';
  value = 50;
  displayedColumns = ['question', 'action', 'actionu', 'actiond'];

  constructor(private questionService: QuestionService, private router: Router,) { }

  ngOnInit() {

    this.questionService.getAllQuestions().subscribe(data => {
      console.log(data);
      this.questions = data;
      this.isLoading = false;
    })
  }

  questionDetails(id: number) {
    this.router.navigate(['questionDetails', id]);
    console.log(id);
  }

  deleteQuestion(id: number) {
    this.questionService.deleteQuestionById(id).
    subscribe((data) => {
        console.log(data);
        this.ngOnInit();
      },( error) => console.log(error));
  }

  editQuestion(id: number) {

    this.router.navigate(['updateQuestion', id]);

    console.log(id);
  }

  addQuestion() {
    this.router.navigate(['addQuestion']);
  }

  search() {
    this.isLoading = true;
    this.questions = this.questions.filter(res => {
      if (!this.questions) {
        this.questionService.getAllQuestions().subscribe(data => {
          this.questions = data;
          console.log(data);
        })
      }
      else {
        (error: any) => console.log(error);
      }
      return res.question.toLocaleLowerCase().match(this.question.toLocaleLowerCase());
    })
  }

}
