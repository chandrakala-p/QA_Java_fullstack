export interface IUser{
    id : number;
    userName : string;
    password : string;
    userEmail : string;
}