export class Answer {
    id: number = 0;
    answerString: string = "";
}
