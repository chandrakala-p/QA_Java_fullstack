import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Question } from '../question';
import { QuestionService } from '../question.service';

@Component({
  selector: 'app-add-question',
  templateUrl: './add-question.component.html',
  styleUrls: ['./add-question.component.css']
})
export class AddQuestionComponent implements OnInit {

  question: Question = new Question();

  submitted1 = false;

  constructor(private questionService: QuestionService, private router: Router) { }

  ngOnInit() {

  }

  newUser(): void {
    this.submitted1 = false;
    this.question = new Question();
  }

  save() {
    this.questionService.addQuestion(this.question)
      .subscribe(data => console.log(data), error => console.log(error));
    this.question = new Question();
    this.questionsList();
  }
  questionsList() {
    this.router.navigate(['questions']);
  }

  onSubmit() {
    this.submitted1 = true;
    this.save();
  }




}