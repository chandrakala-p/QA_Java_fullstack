import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddAnswerComponent } from './add-answer/add-answer.component';
import { AddQuestionComponent } from './add-question/add-question.component';
import { AdminComponent } from './admin/admin.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AnswerDetailsComponent } from './answer-details/answer-details.component';
import { AnswerListComponent } from './answer-list/answer-list.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { QuestionDetailsComponent } from './question-details/question-details.component';
import { QuestionsComponent } from './questions/questions.component';
import { RegisterComponent } from './register/register.component';
import { UpdateAnswerComponent } from './update-answer/update-answer.component';
import { UpdateQuestionComponent } from './update-question/update-question.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: '', pathMatch: 'full', redirectTo: 'home' },
  { path: 'admin', component: AdminComponent },
  { path: 'adminpage', component: AdminpageComponent },



  { path: 'questions', component: QuestionsComponent },
  { path: 'addQuestion', component: AddQuestionComponent },
  { path: 'updateQuestion/:id', component: UpdateQuestionComponent },
  { path: 'questionDetails/:id', component: QuestionDetailsComponent },


  { path: 'answers', component: AnswerListComponent },
  { path: 'addAnswer', component: AddAnswerComponent },
  { path: 'updateAnswer/:id', component: UpdateAnswerComponent },
  { path: 'answerDetails/:id', component: AnswerDetailsComponent },



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
