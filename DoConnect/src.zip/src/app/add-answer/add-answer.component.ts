import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Answer } from '../answer';
import { AnswerService } from '../answer.service';

@Component({
  selector: 'app-add-answer',
  templateUrl: './add-answer.component.html',
  styleUrls: ['./add-answer.component.css']
})
export class AddAnswerComponent implements OnInit {

  answer: Answer = new Answer();

  submitted = false;

  constructor(private answerService: AnswerService, private router: Router) { }

  ngOnInit() {

  }

  newUser(): void {
    this.submitted = false;
    this.answer = new Answer();
  }

  save() {
    this.answerService.addAnswer(this.answer)
      .subscribe(data => console.log(data), error => console.log(error));
    this.answer = new Answer();
    this.answersList();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }


  answersList() {
    this.router.navigate(['answers']);
  }

}
